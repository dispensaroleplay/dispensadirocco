# La Dispensa Di Rocco — Site RP

## Structure

```text
la-dispensa-di-rocco/
├── index.html
├── styles.css
├── script.js
└── assets/
    └── logo.png
```

## Mise en ligne sur GitHub

1. Ouvre ton dépôt GitHub `la-dispensa-di-rocco`.
2. Clique sur **Add file** → **Upload files**.
3. Envoie :
   - `index.html`
   - `styles.css`
   - `script.js`
   - le dossier `assets` avec `logo.png`
4. Clique sur **Commit changes**.

## Cloudflare Pages

Si tu utilises le dépôt GitHub :

- Framework preset : `None`
- Build command : vide
- Build output directory : `/`

Puis lance le déploiement.

## À personnaliser

Cherche dans `index.html` les textes :
- `À personnaliser`
- `À compléter`

Tu pourras y mettre :
- horaires RP
- adresse RP
- téléphone RP
- Discord
- vrais plats et vrais prix

## Galerie

Pour remplacer un bloc de galerie par une vraie image, ajoute par exemple :

```html
<img src="assets/restaurant.jpg" alt="Salle du restaurant">
```

et place l'image correspondante dans le dossier `assets`.

## Important

Le formulaire de réservation est une démo front-end.
Il affiche une confirmation, mais n'envoie encore rien à Discord ou à une base de données.
